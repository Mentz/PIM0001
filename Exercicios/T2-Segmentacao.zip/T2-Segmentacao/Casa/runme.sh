python2 segmentar.py casa.jpeg 240 0 400
