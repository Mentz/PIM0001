python2 segmentar.py solda.png 180 0 4000
